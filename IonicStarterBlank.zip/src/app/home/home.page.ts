import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  title='Home';
  nama='Rengko Panusunan Malau';
  kelas='IF 4 Batamindo';
  nim='3311811031';
  prodi='Teknik Informatika'
  spp='5500000';



  constructor() {}

}
